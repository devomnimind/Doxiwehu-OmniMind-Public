# DESI LyA Sample Materialization (20260218T170112Z)

- sample_root: `/home/fahbrain/projects/omnimind/data/external/desi_edr_lya_fuji_v03_sample_20260218`
- collection: `astro_desi_lya_sample_live`
- files_count: `11`
- delta_download_attempted: `0`
- delta_downloaded: `0`
- total_size_bytes: `1799354`

## Categories
- configs: `4`
- delta: `3`
- log: `3`
- root: `1`

JSON: `reports_runtime/desi_lya_sample_materialization_20260218T170112Z.json`
