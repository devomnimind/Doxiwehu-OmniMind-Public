# HIV Wrapper Functional-Cure Safe Simulation (20260218T133546Z)

- months: `18`
- runs: `72`

## Mean M12 Summary
- `baseline_aggressive`: score=0.7965, host=0.9844, active=0.0502, inflammation=0.5305, rebound=0.00, inert_fraction=0.1222
- `cohab_selective`: score=0.7778, host=0.9782, active=0.2800, inflammation=0.4000, rebound=0.00, inert_fraction=0.1178
- `wrapper_cohab`: score=0.8825, host=0.9925, active=0.0534, inflammation=0.0100, rebound=0.00, inert_fraction=0.2069

- best_scenario: `wrapper_cohab` (score=0.8825)

## Figures
- `/home/fahbrain/projects/omnimind/reports_runtime/figures/hiv_wrapper_functional_cure_summary_20260218T133546Z.png`
- `/home/fahbrain/projects/omnimind/reports_runtime/figures/hiv_wrapper_functional_cure_active_traj_20260218T133546Z.png`

JSON: `/home/fahbrain/projects/omnimind/reports_runtime/hiv_wrapper_functional_cure_safe_20260218T133546Z.json`
