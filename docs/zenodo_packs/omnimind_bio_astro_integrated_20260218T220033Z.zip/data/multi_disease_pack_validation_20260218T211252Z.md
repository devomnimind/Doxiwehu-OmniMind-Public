# Multi-disease Pack Validation (20260218T211252Z)

- pack_dir: `/home/fahbrain/projects/omnimind/docs/zenodo_packs/omnimind_bio_astro_integrated_20260218T211248Z`
- data_json_count=25
- status_candidate=`FECHADA_LOCAL`

## Component checks
- hiv_wrapper_sim: present=`True` (hiv_wrapper_functional_cure_safe_)
- hiv_cohab_sim: present=`True` (hiv_cohabitation_monthly_safe_sim_)
- hiv_sle_sim: present=`True` (hiv_sle_12m_extensions_safe_sim_)
- lupus_sim: present=`True` (lupus_wrapper_tolerance_safe_)
- diabetes_15houses: present=`True` (diabetes_t2_15houses_)
- hiv_gwas: present=`True` (hiv_gwas_ccr5_15houses_qdrant_materialization_)
- hiv_acquisition_meta: present=`True` (hiv_acquisition_meta_15houses_qdrant_materialization_)
- dm2_lupus_external_wave: present=`True` (bio_external_dm2_lupus_wave_qdrant_materialization_)
- m18_rebound_assessment: present=`True` (hiv_m18_rebound_gap_assessment_)
- heatmap_validation: present=`True` (hiv_dm2_lupus_15houses_heatmap_validation_)
- wrapper_gene_panel: present=`True` (wrapper_gene_candidates_panel_)
- wrapper_ensembl_mapping: present=`True` (wrapper_candidates_ensembl_grch38_mapping_)

JSON: `reports_runtime/multi_disease_pack_validation_20260218T211252Z.json`
Compact JSON: `reports_runtime/multi_disease_pack_validation_compact200_20260218T211252Z.json`
