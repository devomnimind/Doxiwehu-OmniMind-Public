# Wrapper Candidates -> Ensembl GRCh38 Mapping (20260218T175521Z)

- candidates=15
- rsid_mapped_grch38=1/1
- gene_symbol_mapped=14/14
- status_candidate=`FECHADA_LOCAL`

## Top rows
- `HLA-B*57:01`: symbol=HLA-B | rsid_mapped=False | gene_mapped=True
- `HLA-C*06:02`: symbol=HLA-C | rsid_mapped=False | gene_mapped=True
- `HLA-B*27:05`: symbol=HLA-B | rsid_mapped=False | gene_mapped=True
- `HLA-C*07:01`: symbol=HLA-C | rsid_mapped=False | gene_mapped=True
- `HLA-C*07:02`: symbol=HLA-C | rsid_mapped=False | gene_mapped=True
- `HLA-B*07:02`: symbol=HLA-B | rsid_mapped=False | gene_mapped=True
- `HLA-B*08:01`: symbol=HLA-B | rsid_mapped=False | gene_mapped=True
- `HLA-C*08:02`: symbol=HLA-C | rsid_mapped=False | gene_mapped=True
- `HLA-C*04:01`: symbol=HLA-C | rsid_mapped=False | gene_mapped=True
- `HLA-B*13:02`: symbol=HLA-B | rsid_mapped=False | gene_mapped=True
- `HLA-B*14:02`: symbol=HLA-B | rsid_mapped=False | gene_mapped=True
- `HLA-C*12:02`: symbol=HLA-C | rsid_mapped=False | gene_mapped=True
- `HLA-C*02:02`: symbol=HLA-C | rsid_mapped=False | gene_mapped=True
- `HLA-A*25:01`: symbol=HLA-A | rsid_mapped=False | gene_mapped=True
- `rs41557415`: symbol=None | rsid_mapped=True | gene_mapped=False

JSON: `reports_runtime/wrapper_candidates_ensembl_grch38_mapping_20260218T175521Z.json`
Compact JSON: `reports_runtime/wrapper_candidates_ensembl_grch38_mapping_compact200_20260218T175521Z.json`
