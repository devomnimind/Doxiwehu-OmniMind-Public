# Zenodo Rehydration Phase2 Status (20260219T125805Z)

- status: `ACTIVE`
- target_size_bytes: `22914531328`
- delta_bytes_3s: `750640`
- marker_exists: `True`
- active_processes: `3`

JSON: `/home/fahbrain/projects/omnimind/reports_runtime/zenodo_rehydration_phase2_status_20260219T125805Z.json`
