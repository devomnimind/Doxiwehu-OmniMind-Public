# Zenodo Publish Recheck (2026-02-19T01:08:40.787737+00:00)

- deposition_id: `18688532`
- state: `done`
- submitted: `True`
- status: `PUBLISHED_CONFIRMED`
- doi: `10.5281/zenodo.18688532`
- conceptdoi: `10.5281/zenodo.18686119`
- record_url: `https://zenodo.org/record/18688532`
