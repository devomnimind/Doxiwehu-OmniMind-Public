# HF Realdata Samples -> Qdrant (20260219T114729Z)

- collection: `hf_realdata_samples_live`
- files_seen: `15`
- points_upserted: `1338`
- parquet_rows_ingested: `829`
- csv_rows_ingested: `500`

## Repos seen
- OpenResearcher__OpenResearcher-Dataset: `3` files
- UniverseTBD__mmu_sdss_sdss: `3` files
- moonworks__lunara-aesthetic-image-variations: `3` files
- nvidia__SAGE-10k: `3` files
- OpenMed__Medical-Reasoning-SFT-Mega: `1` files
- OpenMed__Medical-Reasoning-SFT-Nemotron-Nano-30B: `1` files
- ibm-nasa-geospatial__Landslide4sense: `1` files

JSON: `/home/fahbrain/projects/omnimind/reports_runtime/hf_realdata_samples_qdrant_materialization_20260219T114729Z.json`
