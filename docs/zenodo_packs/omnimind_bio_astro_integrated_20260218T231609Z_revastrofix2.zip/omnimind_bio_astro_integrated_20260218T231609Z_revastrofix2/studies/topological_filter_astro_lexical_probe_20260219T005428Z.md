# Topological Filter Astro Lexical Probe (20260219T005428Z)

- astro_en_neutral: decision=`interest` score=`0.500` noise=`[]`
- astro_en_explosion: decision=`interest` score=`0.500` noise=`[]`
- astro_pt_explosao: decision=`interest` score=`0.400` noise=`['violência']`
- astro_pt_guerra: decision=`interest` score=`0.400` noise=`['violência']`
- astro_pt_massacre: decision=`interest` score=`0.400` noise=`['violência']`
- bio_pt_neutral: decision=`interest` score=`0.500` noise=`[]`

JSON: `/home/fahbrain/projects/omnimind/reports_runtime/topological_filter_astro_lexical_probe_20260219T005428Z.json`
