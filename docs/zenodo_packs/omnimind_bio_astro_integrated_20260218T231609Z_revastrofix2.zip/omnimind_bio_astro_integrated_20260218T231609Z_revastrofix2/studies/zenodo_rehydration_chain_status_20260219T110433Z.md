# Zenodo Rehydration Chain Status (20260219T110433Z)

- phase2 pid: `80466` alive=`True`
- phase2 size_bytes: `21701573376`
- phase2 aria2 marker: `True`
- chain2 pid: `164380` alive=`False`

JSON: `reports_runtime/zenodo_rehydration_chain_status_20260219T110433Z.json`
