# Zenodo Rehydration Phase2 Status (20260219T104807Z)

- pid: `80466`
- alive: `True`
- size_bytes: `21687697408`
- aria2_state_present: `True`

JSON: `reports_runtime/zenodo_rehydration_phase2_status_20260219T104807Z.json`
