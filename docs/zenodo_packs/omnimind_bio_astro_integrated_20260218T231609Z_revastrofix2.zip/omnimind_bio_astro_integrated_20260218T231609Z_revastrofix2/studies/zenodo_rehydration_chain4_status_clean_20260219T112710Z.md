# Zenodo Rehydration Chain4 Status (Clean)

- marker_exists: `True`
- phase2_size_bytes: `21799895040`
- phase2_aria2_count: `1`
- phase3_aria2_count: `0`
- chain4_waiter_count: `2`

JSON: `reports_runtime/zenodo_rehydration_chain4_status_clean_20260219T112710Z.json`
