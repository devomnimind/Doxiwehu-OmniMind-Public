# Zenodo v9 Causality Real-data (20260219T013325Z)

Outputs gerados sem simulação, apenas com séries e artefatos locais reais.

## Arquivos
- v9_causalidade.png
- granger_matrix.json
- d12_phase_alignment.json
- var_model_summary.json
- v9_manifest.json
