# Rehydrated Biomarker Scan (20260219T121615Z)

- entries_total: `12`
- readable_entries: `7`
- qdrant_points_upserted: `12`

## Top biomarker terms
- nad: `48`
- hsc: `41`
- p16: `37`
- p21: `23`
- il4: `22`
- tfeb: `3`
- nad+: `1`
- eomes: `1`
- sasp: `1`
- cdkn2a: `0`

## Top astro terms
- mcmc: `534`
- bao: `486`
- omega: `178`
- wcdm: `113`
- sdss: `92`
- horizon: `42`
- lya: `26`
- cosmology: `1`
- jwst: `0`
- ly-alpha: `0`

## Top disease terms
- hiv: `43`
- dm2: `37`
- lupus: `0`
- diabetes: `0`
- microbiome: `0`
- colorectal: `0`
- glaucoma: `0`

JSON: `/home/fahbrain/projects/omnimind/reports_runtime/rehydrated_biomarker_scan_20260219T121615Z.json`
