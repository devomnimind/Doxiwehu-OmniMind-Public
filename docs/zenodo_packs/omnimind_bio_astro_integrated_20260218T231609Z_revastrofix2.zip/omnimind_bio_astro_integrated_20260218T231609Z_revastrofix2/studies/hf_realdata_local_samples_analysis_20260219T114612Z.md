# HF Realdata Local Samples Analysis

- sample_root: `/home/fahbrain/projects/omnimind/data/external/hf_collections_samples`
- files_total: `54`
- files_ok: `13`
- data_files_ok: `7`

- `OpenMed__Medical-Reasoning-SFT-Mega`: files=`5` ok=`1` data_ok=`1`
- `OpenMed__Medical-Reasoning-SFT-Nemotron-Nano-30B`: files=`5` ok=`1` data_ok=`1`
- `OpenResearcher__OpenResearcher-Dataset`: files=`10` ok=`3` data_ok=`1`
- `UniverseTBD__mmu_sdss_sdss`: files=`10` ok=`2` data_ok=`2`
- `ibm-nasa-geospatial__Landslide4sense`: files=`4` ok=`1` data_ok=`1`
- `moonworks__lunara-aesthetic-image-variations`: files=`10` ok=`3` data_ok=`1`
- `nvidia__SAGE-10k`: files=`10` ok=`2` data_ok=`0`

JSON: `reports_runtime/hf_realdata_local_samples_analysis_20260219T114612Z.json`
