# Zenodo Bio+Astro Pack Refresh (20260219T143902Z)

- classification: `real-data-local`
- pack_dir: `docs/zenodo_packs/omnimind_bio_astro_integrated_20260218T231609Z_revastrofix2`
- files_count: `232`
- zip_path: `docs/zenodo_packs/omnimind_bio_astro_integrated_20260218T231609Z_revastrofix2.zip`
- zip_sha256: `306fae9321637803ef455be32e30b7f9c3b6a8e965f13867bad4dfd091e36a05`

JSON: `reports_runtime/zenodo_bio_astro_pack_refresh_20260219T143902Z.json`
