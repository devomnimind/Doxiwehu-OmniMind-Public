# Requested Root Archives Qdrant Materialization (20260219T131353Z)

- materialized_total: `5` / `5`
- vector_size: `16`

## Collections
- `astro_brown_dwarfs_photometric_17684859_live`: entries=`1`, table_rows=`0`, points_after=`2`
- `astro_gmos_gri_fits_56059_live`: entries=`17`, table_rows=`0`, points_after=`136`
- `bio_gemini_multimorbidity_ltc_14824760_live`: entries=`1`, table_rows=`0`, points_after=`90`
- `astro_extrasolar_asteroid_transits_1317527_live`: entries=`1`, table_rows=`0`, points_after=`1`
- `chem_tandem_mass_spectra_llm_17555571_live`: entries=`13`, table_rows=`30138`, points_after=`30157`

JSON: `/home/fahbrain/projects/omnimind/reports_runtime/requested_root_archives_qdrant_materialization_20260219T131353Z.json`
