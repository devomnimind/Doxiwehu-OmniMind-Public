# pCloud Snapshot Cleanup (20260219T142034Z)

- classification: `real-data-local`
- target_remote: `pcloud:omnimind_offload/snapshots_autonomous_loop`
- keep_last_zips: `120`
- before_files: `273` bytes=`164331691307`
- deleted_files: `152` bytes=`88007670749`
- failed_files: `0`
- after_files: `121` bytes=`76324020558`
- pcloud_about_after: `{'total': 536870912000, 'used': 449503708675, 'free': 87367203325}`

JSON: `/home/fahbrain/projects/omnimind/reports_runtime/pcloud_snapshot_cleanup_20260219T142034Z.json`
