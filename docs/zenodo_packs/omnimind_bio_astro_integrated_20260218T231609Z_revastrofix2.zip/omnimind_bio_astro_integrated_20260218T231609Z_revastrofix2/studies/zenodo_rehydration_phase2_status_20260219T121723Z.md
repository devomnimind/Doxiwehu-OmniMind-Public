# Zenodo Rehydration Phase2 Status (20260219T121723Z)

- status: `ACTIVE`
- target_size_bytes: `22029555844`
- marker_exists: `True`
- active_processes: `3`

JSON: `/home/fahbrain/projects/omnimind/reports_runtime/zenodo_rehydration_phase2_status_20260219T121723Z.json`
