# Requested Root Archives Analysis (20260219T131602Z)

- found: `5` / `5`

## Archives
- `Photometric Measurements for T- and Y-Type Brown Dwarfs_17684859.zip`: entries=`1`, files=`1`, ext_top=`{'.txt': 1}`
- `GB GMOS gri-band coadded and fully calibrated FITS images_56059.zip`: entries=`17`, files=`17`, ext_top=`{'.tgz': 17}`
- `GEMINI-multimorbidity_GEMINI-LTC-code-list-Public_14824760.zip`: entries=`1`, files=`1`, ext_top=`{'.zip': 1}`
- `Multi-wavelength Photometric Study of the Transits of an Extrasolar Asteroid_1317527.zip`: entries=`1`, files=`1`, ext_top=`{'.pdf': 1}`
- `Simulating Tandem Mass Spectra for Small Molecules using a General-Purpose Large-Language Model_17555571.zip`: entries=`13`, files=`13`, ext_top=`{'.txt': 5, '.msp': 2, '.csv': 2, '.xlsx': 2, '.json': 1, '.py': 1}`

JSON: `/home/fahbrain/projects/omnimind/reports_runtime/requested_root_archives_analysis_20260219T131602Z.json`
