# Zenodo Rehydration Phase2 Status (20260219T122852Z)

- status: `ACTIVE`
- target_size_bytes: `22222471168`
- delta_bytes_4s: `1048576`
- marker_exists: `True`
- active_processes: `3`

JSON: `/home/fahbrain/projects/omnimind/reports_runtime/zenodo_rehydration_phase2_status_20260219T122852Z.json`
