# Reeds Rehydration Index Status (20260219T003121Z)

- process: `scripts/science/index_reeds_neurais.py`
- status: `finished` (exit `0`)
- collections_total: `162`
- kb_reeds_neurais: `0`
- erika_reeds_light_map: `1000`

## Diagnosis
kb_reeds_neurais remained empty after run due to runtime filtering path rejecting all chunks.

## Next step
Use dedicated raw materializer path for reeds metadata/arrays (without ethical text-chunk gating) into separate collection, preserving traceability.

JSON: `reports_runtime/reeds_rehydration_index_status_20260219T003121Z.json`
