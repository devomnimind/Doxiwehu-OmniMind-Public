# Termodinâmica Psicanalítica × Fractal (Real-data) (20260219T012454Z)

- source_md: `/home/fahbrain/projects/omnimind/Doxihewu Omnmind_Termodinâmica, psicanálise e Teoria da Informação.md`
- source_fractal_image: `/home/fahbrain/projects/omnimind/docs/zenodo_packs/omnimind_bio_astro_integrated_20260218T231609Z_revastrofix2/images/astro_bio_fractal_partial_20260218T170121Z.png`
- lexical_token_entropy_bits: `9.944999`
- boxcount_fractal_dimension_est: `1.276156`

## Lexical counts
- entropia_or_entropy: `20`
- termodinamica_or_thermo: `18`
- fractal: `15`
- fagocitose_or_phagocyt: `14`
- audit_chain: `2`

## Nota metodológica
- Não há série temporal conjunta Doxihewu×fractal aqui para teste de correlação/causalidade.
- Portanto, este artefato reporta métricas reais observacionais (entropia lexical e dimensão fractal estimada), sem inferência causal.
