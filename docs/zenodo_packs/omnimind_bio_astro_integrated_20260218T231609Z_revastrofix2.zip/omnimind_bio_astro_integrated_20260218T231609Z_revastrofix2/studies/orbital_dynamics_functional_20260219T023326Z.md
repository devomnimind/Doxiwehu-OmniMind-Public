# Orbital Dynamics Functional Analysis (20260219T023326Z)

- rows_combined_clean: `56123`
- gal_plane_cross_rate: `0.0000`
- corr house12 vs z (pearson): `0.041003469985143995`
- corr house12 vs z (spearman): `-0.05732294618910989`
- clusters_k_used: `5`
- status_candidate: `PASS_LOCAL`

JSON: `/home/fahbrain/projects/omnimind/reports_runtime/orbital_dynamics_functional_20260219T023326Z.json`
Figure: `/home/fahbrain/projects/omnimind/output/img/orbital_dynamics_full_analysis_20260219T023326Z.png`
