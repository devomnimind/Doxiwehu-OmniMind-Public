# Zenodo Rehydration Readiness (20260219T025639Z)

## Disk snapshot (GB)
- /home: `{'total_gb': 273.948, 'used_gb': 206.523, 'free_gb': 53.439}`
- /mnt/welinton_users: `{'total_gb': 465.662, 'used_gb': 295.412, 'free_gb': 170.251}`
- /: `{'total_gb': 365.615, 'used_gb': 303.582, 'free_gb': 43.39}`

## Records
- 18496170 | files=8 | present=3 | missing=5 | total_bytes=50829888876
- 1173657 | files=15 | present=5 | missing=10 | total_bytes=35808177653
- 2641868 | files=2 | present=1 | missing=1 | total_bytes=4845496320
- 6797842 | files=1 | present=0 | missing=1 | total_bytes=24780453704
- 7327525 | files=1 | present=0 | missing=1 | total_bytes=37077706064

## Download manifests
- small-first: `/home/fahbrain/projects/omnimind/reports_runtime/zenodo_rehydration_smallfirst_20260219T025639Z.txt` (9 entries)
- full-external: `/home/fahbrain/projects/omnimind/reports_runtime/zenodo_rehydration_full_external_20260219T025639Z.txt` (27 entries)

JSON: `/home/fahbrain/projects/omnimind/reports_runtime/zenodo_rehydration_readiness_20260219T025639Z.json`
