# Zenodo Pack Consistency Audit (20260220T001250Z)

- pack_dir: `/home/fahbrain/projects/omnimind/docs/zenodo_packs/omnimind_bio_astro_integrated_20260218T231609Z_revastrofix2`
- manifest_entries: `265`
- manifest_errors: `0`
- reference_candidates: `103`
- internal_refs_ok: `98`
- external_refs_ok: `5`
- missing_refs: `0`
- status_candidate: `PASS_LOCAL`

## Missing refs (top 20)
- none
