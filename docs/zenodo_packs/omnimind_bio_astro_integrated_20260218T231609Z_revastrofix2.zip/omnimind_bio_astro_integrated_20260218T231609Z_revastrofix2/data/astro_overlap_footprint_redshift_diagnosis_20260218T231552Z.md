# Astro Overlap Footprint+Redshift Diagnosis (20260218T231552Z)

- sdss_total_points: `405000`
- sdss_points_inside_desi_box: `41`
- desi_redshift_floor: `1.9875929980594196`
- sdss_inside_box_points_with_z_ge_desi_floor: `0`

## Interpretation
Strict SDSS×DESI object matches are blocked by joint footprint+redshift support: very few SDSS points lie in DESI sky box and none reaches DESI redshift floor in this local SDSS subset.

JSON: `reports_runtime/astro_overlap_footprint_redshift_diagnosis_20260218T231552Z.json`
