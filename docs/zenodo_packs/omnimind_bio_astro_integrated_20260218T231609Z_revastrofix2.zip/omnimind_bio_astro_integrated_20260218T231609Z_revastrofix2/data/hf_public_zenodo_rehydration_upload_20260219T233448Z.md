# HF Public Zenodo Rehydration Upload (20260219T233448Z)

- repo: `fabricioslv/omnimind-zenodo-rehydration-public-bridge`
- url: `https://huggingface.co/datasets/fabricioslv/omnimind-zenodo-rehydration-public-bridge`
- path_prefix: `rehydration/hf_public_zenodo_rehydration_textbridge_20260219T233409Z`
- attempted_files: `24`
- uploaded_files: `24`
- error_files: `0`
- remote_prefix_files: `24`
- remote_total_files: `56`