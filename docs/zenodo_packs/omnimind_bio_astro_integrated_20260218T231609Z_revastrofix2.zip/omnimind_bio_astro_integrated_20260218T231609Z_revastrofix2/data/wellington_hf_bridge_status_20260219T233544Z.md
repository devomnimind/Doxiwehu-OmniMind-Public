# Wellington + HF Bridge Status (20260219T233544Z)

- provenance: `real-data-local`
- wellington path: `/mnt/welinton_users/Public/datasets/zenodo_records/full_external/18496170`
- 18496170 .aria2 markers: `5`
- active download process for 18496170: `False`
- HF repo: `https://huggingface.co/datasets/fabricioslv/omnimind-zenodo-rehydration-public-bridge`
- HF total files: `56`
- latest HF upload report: `reports_runtime/hf_public_zenodo_rehydration_upload_20260219T233448Z.json`

## v10 Blocking Assessment
- blocking: `False`
- Key rehydration evidence from 1173657/2641868/6797842/7327525 is already extracted and materialized in local reports/Qdrant.
- 18496170 large chains are complementary for expansion and should be resumed, but are not required to preserve current v10 conclusions.

## Recommended Next Actions
- Restart 18496170 download controller (aria2 or alternative) with resume from existing partial files.
- Do not delete partial ZIPs; keep .aria2 pairing for resume.
- After completion, run extraction + qdrant materialization pass and publish a second HF bridge package with selected derived outputs.