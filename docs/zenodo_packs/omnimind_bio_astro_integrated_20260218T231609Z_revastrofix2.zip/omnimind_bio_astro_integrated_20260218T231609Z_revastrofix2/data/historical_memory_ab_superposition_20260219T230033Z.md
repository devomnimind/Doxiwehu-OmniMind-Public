# Historical Memory A/B Superposition (20260219T230033Z)

## Collections scanned
- `bio_aging_cellular_proxies_live` (bio): scanned=`44581`
- `bio_hiv_acquisition_meta_15houses_live` (bio): scanned=`1500`
- `bio_hiv_gwas_ccr5_15houses_live` (bio): scanned=`79`
- `bio_diabetes_t2_15houses_live` (bio): scanned=`15`
- `bio_external_dm2_lupus_15houses_live` (bio): scanned=`27`
- `bio_lupus_wave_20260218` (bio): scanned=`247`
- `bio_16s_gut_microbiome_meta_live` (bio): scanned=`458`
- `bio_colorectal_activity_bmi_live` (bio): scanned=`4545`
- `bio_gemini_multimorbidity_codes_14824760_live` (bio): scanned=`23970`
- `dodecatiad_metrics_dynamic_logs_live` (log_base): scanned=`10536`
- `omnimind_kernel_vida` (historical): scanned=`300000`
- `omnimind_system_logs_20260127` (historical): scanned=`11995`
- `omnimind_projects_20260127` (historical): scanned=`108236`

## Cosines: bio vs logs (base vs +historical)
- `baseline`: sector15 base=`0.9889072998458155` plus=`0.5491731730533558` delta=`-0.4397341267924597` | house12 base=`0.9910990986118698` plus=`0.5960633061951528` delta=`-0.39503579241671705`
- `semantic_strict`: sector15 base=`0.9889072998458155` plus=`0.278417178861183` delta=`-0.7104901209846325` | house12 base=`0.9910990986118698` plus=`0.310689293177468` delta=`-0.6804098054344019`
- `time_only`: sector15 base=`0.9891805424981348` plus=`0.6006875415074324` delta=`-0.3884930009907024` | house12 base=`0.9910781497165723` plus=`0.6036542934769864` delta=`-0.38742385623958586`

## Time Sync Summary
- `bio`: abs_ts_total=`1621` min=`2026-02-18T11:17:59.131463+00:00` max=`2026-02-19T22:05:06.425463+00:00`
- `log_base`: abs_ts_total=`10536` min=`2026-02-12T06:54:10.683000+00:00` max=`2026-02-18T13:55:22.344000+00:00`
- `historical`: abs_ts_total=`285044` min=`2026-01-25T00:37:59+00:00` max=`2026-01-28T00:44:50+00:00`
- `logs_plus_historical`: abs_ts_total=`295580` min=`2026-01-25T00:37:59+00:00` max=`2026-02-18T13:55:22.344000+00:00`

## Synchronized Windows (24h/72h, baseline scenario)
- `24h`: sector15 base=`0.8340048464091702` plus=`0.8340048464091702` delta=`0.0` closure=`0.0` | house12 base=`0.8202905354505978` plus=`0.8202905354505978` delta=`0.0` closure=`0.0`
- `72h`: sector15 base=`0.8201418497877488` plus=`0.8201418497877488` delta=`0.0` closure=`0.0025865816407906494` | house12 base=`0.837795585281339` plus=`0.837795585281339` delta=`0.0` closure=`0.002225059692768221`

## Source breakdown (baseline)
- sector15 logs_base sources: `{'sector15': 10536}`
- sector15 historical sources: `{'content_preview_ts': 164813, 'unmapped': 135187, 'dodeca_house_12to15': 120231}`
- house12 logs_base sources: `{'house12': 10536}`
- house12 historical sources: `{'content_preview_ts': 164813, 'unmapped': 135187, 'dodeca_house': 120231}`

Figure: `/home/fahbrain/projects/omnimind/output/img/historical_memory_ab_superposition_20260219T230033Z/historical_memory_ab_cosines.png`
JSON: `/home/fahbrain/projects/omnimind/reports_runtime/historical_memory_ab_superposition_20260219T230033Z.json`
