# Null Model H0 (Cosine Alignment) - 20260220T105310Z

- source: `docs/zenodo_packs/omnimind_bio_astro_integrated_20260218T231609Z_revastrofix2/data/bio_logs_cosine_contamination_diagnosis_20260219T203902Z.json`
- n_permutations: `20000`

## Results
- `baseline` `sector15`: obs=`0.989392` | perm_mean=`0.989078` p_ge=`0.3747` z=`0.348` | rand_mean=`0.550248` p_ge=`0` z=`3.135`
- `baseline` `house12`: obs=`0.991082` | perm_mean=`0.990910` p_ge=`0.3933` z=`0.306` | rand_mean=`0.557971` p_ge=`0` z=`2.831`
- `exclude_hw` `sector15`: obs=`0.989392` | perm_mean=`0.989069` p_ge=`0.37185` z=`0.360` | rand_mean=`0.548465` p_ge=`0` z=`3.113`
- `exclude_hw` `house12`: obs=`0.991082` | perm_mean=`0.990900` p_ge=`0.3838` z=`0.322` | rand_mean=`0.559680` p_ge=`0` z=`2.822`
- `semantic_strict` `sector15`: obs=`0.493443` | perm_mean=`0.207747` p_ge=`0.0684` z=`1.870` | rand_mean=`0.550019` p_ge=`0.6481` z=`-0.401`
- `semantic_strict` `house12`: obs=`0.551745` | perm_mean=`0.250345` p_ge=`0.0883` z=`2.058` | rand_mean=`0.559324` p_ge=`0.5224` z=`-0.050`
- `semantic_strict_exclude_hw` `sector15`: obs=`0.493443` | perm_mean=`0.210026` p_ge=`0.06795` z=`1.862` | rand_mean=`0.549439` p_ge=`0.6501` z=`-0.401`
- `semantic_strict_exclude_hw` `house12`: obs=`0.551745` | perm_mean=`0.248486` p_ge=`0.0833` z=`2.070` | rand_mean=`0.561151` p_ge=`0.52795` z=`-0.061`
- `time_only` `sector15`: obs=`0.989181` | perm_mean=`0.989314` p_ge=`0.7126` z=`-0.545` | rand_mean=`0.550752` p_ge=`0` z=`3.131`
- `time_only` `house12`: obs=`0.991078` | perm_mean=`0.990990` p_ge=`0.40985` z=`0.496` | rand_mean=`0.559985` p_ge=`0` z=`2.804`
- `time_only_exclude_hw` `sector15`: obs=`0.989181` | perm_mean=`0.989317` p_ge=`0.71775` z=`-0.562` | rand_mean=`0.550054` p_ge=`0` z=`3.114`
- `time_only_exclude_hw` `house12`: obs=`0.991078` | perm_mean=`0.990990` p_ge=`0.4128` z=`0.494` | rand_mean=`0.560903` p_ge=`0` z=`2.814`
