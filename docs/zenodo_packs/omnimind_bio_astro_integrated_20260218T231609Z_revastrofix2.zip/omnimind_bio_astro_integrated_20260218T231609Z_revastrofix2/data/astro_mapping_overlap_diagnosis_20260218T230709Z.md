# Astro Mapping Overlap Diagnosis (20260218T230709Z)

- sdss_collection: `sdss_structures_objectlevel_live_v2`
- desi_collection: `astro_desi_lya_objectlevel_live`
- sdss_points_with_ra_dec_z: `405000`
- desi_points_with_ra_dec_z: `24724`

## Nearest-neighbor summary
- angular median (deg): `0.36926206752707474`
- angular p95 (deg): `0.6386752879400496`
- |Δz| median: `1.8955544864116063`
- |Δz| p95: `2.9602650395865595`

## Threshold grid (selected)
- angle<=0.2 deg & |Δz|<=0.05: matches=`0` rate=`0.000000`
- angle<=0.5 deg & |Δz|<=0.1: matches=`0` rate=`0.000000`
- angle<=1.0 deg & |Δz|<=0.2: matches=`0` rate=`0.000000`
- angle<=2.0 deg & |Δz|<=0.5: matches=`0` rate=`0.000000`
- angle<=5.0 deg & |Δz|<=1.0: matches=`35` rate=`0.001416`

## Figures
- `output/img/astro_mapping_overlap_20260218T230709Z/nn_angular_distance_hist.png`
- `output/img/astro_mapping_overlap_20260218T230709Z/nn_redshift_delta_hist.png`
- `output/img/astro_mapping_overlap_20260218T230709Z/nn_angular_cdf.png`
- `output/img/astro_mapping_overlap_20260218T230709Z/nn_redshift_delta_cdf.png`

JSON: `reports_runtime/astro_mapping_overlap_diagnosis_20260218T230709Z.json`
