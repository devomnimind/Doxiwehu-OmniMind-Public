# Continuation Round3 Status (20260219T231233Z)

- status: `continuing_with_historical_ab_and_download_monitor`
- historical_memory_ab_report: `/home/fahbrain/projects/omnimind/reports_runtime/historical_memory_ab_superposition_20260219T230033Z.json`

## Historical A/B Deltas
- `baseline`: sector15_delta=`-0.4397341267924597` | house12_delta=`-0.39503579241671705`
- `semantic_strict`: sector15_delta=`-0.7104901209846325` | house12_delta=`-0.6804098054344019`
- `time_only`: sector15_delta=`-0.3884930009907024` | house12_delta=`-0.38742385623958586`

## 18496170 Progress
- files_complete: `3` / `8`
- files_active_markers: `5`
- `LCDM.zip`: `8253161796` / `9424260708` (87.574%) marker=`True`
- `LCDM_Mnu-d3.zip`: `7424732172` / `8482430624` (87.531%) marker=`True`
- `wCDM.zip`: `8382034368` / `9575741651` (87.534%) marker=`True`
- `LCDM_OmegaK.zip`: `9954131968` / `11373928818` (87.517%) marker=`True`
- `w0waCDM.zip`: `10465837056` / `11958795740` (87.516%) marker=`True`
- `anesthetic_2.12.0.dev0+lukashergt-devel.zip`: `6463623` / `6463623` (100.000%) marker=`False`
- `consistency_of_standard_cosmologies__plotting_code_v1.0.0.zip`: `2661590` / `2661590` (100.000%) marker=`False`
- `consistency_of_standard_cosmologies__figures_v1.0.0.zip`: `5606122` / `5606122` (100.000%) marker=`False`

## Memory Tier2 Footprint
- `omnimind_kernel_vida`: `1077553` (ok)
- `omnimind_ide_soberano`: `228703` (ok)
- `omnimind_projects_20260127`: `108236` (ok)
- `omnimind_corpo_simbolico`: `69435` (ok)
- `omnimind_mega_corpus`: `45269` (ok)
- `omnimind_system_logs_20260127`: `11995` (ok)
- `kb_reeds_neurais`: `124` (ok)

JSON: `/home/fahbrain/projects/omnimind/reports_runtime/continuation_round3_status_20260219T231233Z.json`
