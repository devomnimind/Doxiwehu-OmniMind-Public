# Dodecatiad Baseline vs Log Variance Audit (20260218T165940Z)

## Core
- qdrant_role: `minimum survivability/state anchor`
- variance_source: `daily daemon logs`
- sanctuary_trigger_evidence_count: `17617`
- cross_run_temporal_status: `NO_TEMPORAL_OVERLAP`

## Qdrant mode inference
- mode_inference: `baseline_survival_minimum`
- points: `1834`

## Log variance (quadruple)
- phi std: `0.35499725231563717`
- sigma std: `0.09624922239499276`
- epsilon std: `0.07888638136190605`

## Temporal overlap
- overlap_minutes: `0`
- status: `NO_TEMPORAL_OVERLAP`

JSON: `reports_runtime/dodecatiad_qdrant_baseline_vs_log_variance_20260218T165940Z.json`
