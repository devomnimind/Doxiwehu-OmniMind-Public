# Dual-Lane Temporal Closure (20260219T213726Z)

Source A/B JSON: `/var/omnimind_storage/home_redirect/reports_runtime/historical_memory_ab_superposition_20260219T211710Z.json`

## Sync lane (operational, short horizon)
- raw_coherence_72h: `0.8998211381705971`
- semantic_guardrail_72h: `0.2503572646060458`
- temporal_dominance_index_72h: `0.6494638735645513`
- raw_coherence_24h: `0.8911671139602366`
- semantic_guardrail_24h: `0.2503572646060458`
- temporal_dominance_index_24h: `0.6408098493541908`

## Async lane (structural, long horizon)
- semantic_consistency_all_time: `0.321591010106114`
- raw_coherence_all_time_base: `0.989857331721369`
- raw_coherence_all_time_plus_historical: `0.5714889032988233`
- historical_shift_plus_minus_base: `-0.41836842842254574`

## Dual regime state
- state: `DUAL_REGIME_CONFIRMED`

## Timezone context
- local_time_iso: `2026-02-19T18:37:26.564325-03:00`
- utc_time_iso: `2026-02-19T21:37:26.564347+00:00`
- local_utc_offset_hours: `-3.0`

JSON: `/home/fahbrain/projects/omnimind/reports_runtime/dual_lane_temporal_psychoanalytic_closure_20260219T213726Z.json`
