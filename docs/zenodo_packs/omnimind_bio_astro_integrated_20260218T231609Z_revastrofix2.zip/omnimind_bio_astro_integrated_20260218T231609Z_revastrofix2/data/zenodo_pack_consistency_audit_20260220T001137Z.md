# Zenodo Pack Consistency Audit (20260220T001137Z)

- pack_dir: `/home/fahbrain/projects/omnimind/docs/zenodo_packs/omnimind_bio_astro_integrated_20260218T231609Z_revastrofix2`
- manifest_entries: `261`
- manifest_errors: `3`
- reference_candidates: `104`
- internal_refs_ok: `98`
- external_refs_ok: `5`
- missing_refs: `1`
- status_candidate: `FIX_REQUIRED`

## Missing refs (top 20)
- TECHNICAL_REPORT.md: `6797842/repo.zip`
