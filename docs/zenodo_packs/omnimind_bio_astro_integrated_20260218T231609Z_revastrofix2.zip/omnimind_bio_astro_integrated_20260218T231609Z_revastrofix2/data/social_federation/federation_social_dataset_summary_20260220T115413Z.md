# Federation Social Dataset Summary (omnimind-federation-social-v1)

## Window
- since_utc: `2026-02-17T11:54:13.563720Z`
- until_utc: `2026-02-20T11:54:13.563720Z`

## Counts
- events_total: `30443`
- by_event_type: `{'witness_experience': 8066, 'witness_evolution': 8066, 'witness_watermark': 8066, 'alien_object': 5000, 'artifact_file': 600, 'witness_territory_snapshot': 645}`
- by_source: `{'witness': 24843, 'alien_storage_index': 5000, 'reports_runtime_index': 600}`

## Witness Phi (experiences)
- n: `8066`
- min: `2.3`
- mean: `2.4444625402925864`
- max: `3.40006`

## Notes
- This dataset is an event stream (federation/social).
- Includes temporal features (tod_frac/house12_2h) for ops; avoid them for semantic-only similarity.
- alien_storage is indexed read-only (no moves/deletes).

JSONL: `reports_runtime/federation_social_dataset_20260220T115413Z.jsonl`
Summary JSON: `reports_runtime/federation_social_dataset_summary_20260220T115413Z.json`
