# Local Trail Closure Recheck (20260218T211252Z)

## Status
- local_trail_status: `FECHADA_LOCAL`
- pending_technical_items: `0`
- blocked_external_items: `2`

## Core local evidence
- d15_top_pair: `{'pair': 'd15_rekh_proxy x moon_illum_frac', 'r': -0.8323412104628806, 'lag_min': 300}`
- d15_validated_pairs_count: `8`
- dm2_status_candidate: `FECHADA_LOCAL`
- dm2_microbiome_external_collection_points_total: `1143`
- zip_materialized_total: `13`
- qdrant_collections_total: `159`

JSON: `reports_runtime/local_trail_closure_recheck_20260218T211252Z.json`
