# Multi-disease Pack Validation (20260218T211102Z)

- pack_dir: `docs/zenodo_packs/omnimind_bio_astro_integrated_20260218T210329Z`
- data_json_count=18
- status_candidate=`EM_ANDAMENTO`

## Component checks
- hiv_wrapper_sim: present=`False` (hiv_wrapper_functional_cure_safe_)
- hiv_cohab_sim: present=`False` (hiv_cohabitation_monthly_safe_sim_)
- hiv_sle_sim: present=`False` (hiv_sle_12m_extensions_safe_sim_)
- lupus_sim: present=`False` (lupus_wrapper_tolerance_safe_)
- diabetes_15houses: present=`False` (diabetes_t2_15houses_)
- hiv_gwas: present=`False` (hiv_gwas_ccr5_15houses_qdrant_materialization_)
- hiv_acquisition_meta: present=`True` (hiv_acquisition_meta_15houses_qdrant_materialization_)
- dm2_lupus_external_wave: present=`True` (bio_external_dm2_lupus_wave_qdrant_materialization_)
- m18_rebound_assessment: present=`True` (hiv_m18_rebound_gap_assessment_)
- heatmap_validation: present=`True` (hiv_dm2_lupus_15houses_heatmap_validation_)
- wrapper_gene_panel: present=`False` (wrapper_gene_candidates_panel_)
- wrapper_ensembl_mapping: present=`True` (wrapper_candidates_ensembl_grch38_mapping_)

JSON: `reports_runtime/multi_disease_pack_validation_20260218T211102Z.json`
Compact JSON: `reports_runtime/multi_disease_pack_validation_compact200_20260218T211102Z.json`
