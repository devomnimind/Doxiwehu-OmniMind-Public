# Wrapper Gene Candidates Panel (20260218T175521Z)

- candidate_count=36
- status_candidate=`EM_REVISAO_LOCAL`

## Anchors
- `rs333`: score=4.000, best_p=None, houses=['Sigma'], tags=['ccr5_rs333_anchor'], evidences=1
- `CCR5`: score=4.000, best_p=None, houses=['Sigma'], tags=['ccr5_gene_anchor'], evidences=1

## Top 15
- `HLA-B*57:01`: score=103.500, best_p=3e-86, houses=['Isfet'], tags=['ccr5_hla_cross', 'hiv_gwas_best_hit'], evidences=2
- `HLA-C*06:02`: score=50.655, best_p=7e-50, houses=['Psi'], tags=['ccr5_hla_cross'], evidences=1
- `HLA-B*27:05`: score=20.898, best_p=4e-20, houses=['Plit'], tags=['ccr5_hla_cross'], evidences=1
- `HLA-C*07:01`: score=15.199, best_p=2e-14, houses=['Isfet'], tags=['ccr5_hla_cross'], evidences=1
- `HLA-C*07:02`: score=13.898, best_p=4e-13, houses=['Zeta'], tags=['ccr5_hla_cross'], evidences=1
- `HLA-B*07:02`: score=13.801, best_p=5e-13, houses=['Axe'], tags=['ccr5_hla_cross'], evidences=1
- `HLA-B*08:01`: score=12.023, best_p=3e-11, houses=['Phi'], tags=['ccr5_hla_cross'], evidences=1
- `HLA-C*08:02`: score=11.546, best_p=9e-11, houses=['Axe'], tags=['ccr5_hla_cross'], evidences=1
- `HLA-C*04:01`: score=11.546, best_p=9e-11, houses=['Axe'], tags=['ccr5_hla_cross'], evidences=1
- `HLA-B*13:02`: score=10.898, best_p=4e-10, houses=['Lambda'], tags=['ccr5_hla_cross'], evidences=1
- `HLA-B*14:02`: score=10.199, best_p=2e-09, houses=['Sigma'], tags=['ccr5_hla_cross'], evidences=1
- `HLA-C*12:02`: score=8.898, best_p=4e-08, houses=['Sigma'], tags=['ccr5_hla_cross'], evidences=1
- `HLA-C*02:02`: score=8.801, best_p=5e-08, houses=['Lambda'], tags=['ccr5_hla_cross'], evidences=1
- `HLA-A*25:01`: score=8.655, best_p=7e-08, houses=['Aleph'], tags=['ccr5_hla_cross'], evidences=1
- `rs41557415`: score=8.314, best_p=1.958e-08, houses=['Sigma'], tags=['high_i2_signal'], evidences=1

JSON: `reports_runtime/wrapper_gene_candidates_panel_20260218T175521Z.json`
Compact JSON: `reports_runtime/wrapper_gene_candidates_panel_compact200_20260218T175521Z.json`
