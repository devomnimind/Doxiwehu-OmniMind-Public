# Astro-Bio Cycle Sustainment (20260218T170121Z)

## Sustainment Board
- overall_strength: `ROBUST_LOCAL`
- dominant_lag_min: `240`
- strong_pairs(|r|>=0.6): `20`
- very_strong_pairs(|r|>=0.75): `9`
- mean_abs_r_top_validated: `0.7418`

## Claim checks
- moon_illum_frac_to_rekh: r=-0.8291 lag=240 sigma~85.12 p_perm=4.998e-04 status=SUSTAINED_STRONG
- sun_moon_sep_to_rekh: r=-0.8110 lag=240 sigma~81.15 p_perm=4.998e-04 status=SUSTAINED_STRONG
- moon_sep_spica_to_isfet: r=-0.6372 lag=-123 sigma~54.71 p_perm=4.998e-04 status=SUSTAINED_STRONG

## Local SDSS/Ly-alpha presence
- partition_exists=True rows=789
- lya_named_assets_local_count=56

## Publication extras (outside zip)
- `reports_runtime/astro_bio_cycle_heatmap_20260218T170121Z.png`
- `reports_runtime/astro_bio_fractal_partial_20260218T170121Z.png`

JSON: `reports_runtime/astro_bio_cycle_sustainment_20260218T170121Z.json`
Compact JSON: `reports_runtime/astro_bio_cycle_sustainment_compact200_20260218T170121Z.json`
