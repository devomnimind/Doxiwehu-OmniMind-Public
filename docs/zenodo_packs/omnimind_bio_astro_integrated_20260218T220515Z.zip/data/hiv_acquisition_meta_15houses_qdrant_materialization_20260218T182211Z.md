# HIV Acquisition Meta 15-Houses Qdrant Materialization (20260218T182211Z)

- source_zip: `data/runtime/rehydrated_datasets/HIV_acquisition_meta.zip`
- source_member: `HIV_acquisition_meta_sample_size1_filtered_annotated.txt`
- rows_scanned: `5347926`
- rows_valid_p: `5347926`
- rows_genome_wide_sig_p_lt_5e8: `4`
- top_n_materialized: `1500`
- collection: `bio_hiv_acquisition_meta_15houses_live`

## Best Hit
- RSID: `rs41557415`
- CHR: `6` BP: `31323455`
- P: `1.958e-08` Z: `-5.616`

## Notes
- Input is whitespace-delimited summary statistics, not GWAS Catalog TSV schema.
- Materialization stores top p-value signals for vector search/audit.

JSON: `/home/fahbrain/projects/omnimind/reports_runtime/hiv_acquisition_meta_15houses_qdrant_materialization_20260218T182211Z.json`
