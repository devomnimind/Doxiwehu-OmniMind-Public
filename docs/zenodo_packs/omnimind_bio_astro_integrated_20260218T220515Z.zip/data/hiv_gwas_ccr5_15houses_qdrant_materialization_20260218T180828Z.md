# HIV GWAS + CCR5 15-Houses Qdrant Materialization (20260218T180828Z)

- collection: `bio_hiv_gwas_ccr5_15houses_live`
- qdrant_url: `http://127.0.0.1:6333`
- points_upserted: `17`
- gwas_rows: `16`
- ccr5_delta32_detected_grch38: `False`

## Sources
- `/home/fahbrain/Downloads/gwas-association-downloaded_2026-02-18-EFO_0006319.tsv`
- `/home/fahbrain/Downloads/gwas-association-downloaded_2026-02-18-accessionId_GCST90101057.tsv`
- `/home/fahbrain/Downloads/variation_ccr5333.json`

## House Counts
- `Aleph`: `3`
- `Epsilon`: `2`
- `Gamma`: `2`
- `Isfet`: `3`
- `Lambda`: `1`
- `Ma'at`: `1`
- `Omega`: `2`
- `Phi`: `1`
- `Rekh`: `1`
- `Sigma`: `1`

## Best P-value Hit
- snp: `None`
- mapped_gene: `None`
- trait: `None`
- p_value: `None`
- study_accession: `None`

## DM2 Note
- excluded_from_bio_pipeline: `True`
- reason: `Identified as Dark Matter Daily Modulation (DM²) experimental data.`

JSON: `/home/fahbrain/projects/omnimind/reports_runtime/hiv_gwas_ccr5_15houses_qdrant_materialization_20260218T180828Z.json`
