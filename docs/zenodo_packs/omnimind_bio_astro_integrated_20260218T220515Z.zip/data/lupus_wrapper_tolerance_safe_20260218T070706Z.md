# Lupus Wrapper Tolerance Safe Simulation (20260218T070706Z)

- months: `12`
- runs: `72`
- host_margin: `0.01`
- inflam_margin: `0.35`
- wrapper_margin: `0.08`
- profile_source: `/home/fahbrain/projects/omnimind/data/runtime/phagocytosis_house_threshold_profile.json`
- profile_name: `strict_transcriptor_x2`

## Mean M12 Summary
- `baseline_autoimmune`: score=0.7157, host=0.9814, auto_bad=0.0990, treg=0.3284, infl=0.7102, fail_rate=0.4907
- `treg_balanced`: score=0.7529, host=0.9831, auto_bad=0.0795, treg=0.4500, infl=0.5819, fail_rate=0.3935
- `wrapper_tolerance`: score=0.7793, host=0.9878, auto_bad=0.0219, treg=0.5157, infl=0.1950, fail_rate=0.7245
- `wrapper_tolerance_baff_gate`: score=0.7979, host=0.9888, auto_bad=0.0173, treg=0.5334, infl=0.1328, fail_rate=0.6586

- best_scenario: `wrapper_tolerance_baff_gate` (score=0.7979)

## Figures
- `/home/fahbrain/projects/omnimind/reports_runtime/figures/lupus_wrapper_tolerance_summary_20260218T070706Z.png`
- `/home/fahbrain/projects/omnimind/reports_runtime/figures/lupus_wrapper_tolerance_house_fail_heatmap_20260218T070706Z.png`

JSON: `/home/fahbrain/projects/omnimind/reports_runtime/lupus_wrapper_tolerance_safe_20260218T070706Z.json`
