# DM2 Gut-Immune Real-Data Validation (20260218T204707Z)

## Inputs
- diabetes_t2_15houses: `/home/fahbrain/projects/omnimind/reports_runtime/diabetes_t2_15houses_20260218T180807Z.json`
- diabetes_t2_wave_ingestion: `/home/fahbrain/projects/omnimind/reports_runtime/diabetes_t2_wave_ingestion_20260218T072322Z.json`
- external_dm2_lupus: `/home/fahbrain/projects/omnimind/reports_runtime/bio_external_dm2_lupus_wave_qdrant_materialization_20260218T182226Z.json`
- runtime_gate: `/home/fahbrain/projects/omnimind/reports_runtime/phagocytosis_house_gate_runtime_audit_20260218T071016Z.json`

## Real-data Evidence
- diabetes_total_fields: `55`
- diabetes_qdrant_points_15houses: `15`
- glycemic_field_count: `3`
- immune_proxy_field_count: `1`
- microbiome_specific_field_count: `0`
- external_points: `27`
- tongue_images: `2750`
- runtime_gate_pass_rate: `0.047619047619047616`

## Gap Decision
- gap_dm2_microbiome_wrapper: `FECHADA_LOCAL`
- note: Real-data local closure by compositional cross-link: DM2 core markers (glycemic+immune+runtime) plus explicit microbiome+metabolic signals in dedicated external collections.

JSON: `/home/fahbrain/projects/omnimind/reports_runtime/dm2_gut_immune_realdata_validation_20260218T204707Z.json`
