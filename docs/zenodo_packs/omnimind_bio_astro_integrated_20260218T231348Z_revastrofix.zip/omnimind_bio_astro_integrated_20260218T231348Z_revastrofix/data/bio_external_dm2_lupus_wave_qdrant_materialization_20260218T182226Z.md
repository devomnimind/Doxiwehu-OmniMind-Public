# Bio External DM2+Lupus Wave Qdrant Materialization (20260218T182226Z)

- collection: `bio_external_dm2_lupus_15houses_live`
- points_upserted: `27`
- csv_field_points: `18`
- tongue_bucket_points: `6`
- lupus_pdf_points: `3`

## Sources
- diabetes_csv_zip: `data/runtime/rehydrated_datasets/conjunto_diabetes2kagglearchive.zip`
- tongue_zip: `data/runtime/rehydrated_datasets/Type 2 Diabetes Mellitus Tongue Dataset.zip`
- lupus_zip: `data/runtime/rehydrated_datasets/Risk factors of progression from discoid lupus to severe systemic lupus erythematosus a registry-based cohort study of 164 patients.zip`
- notebook: `data/runtime/rehydrated_datasets/life-expectancy-regression-with-ann.ipynb`

## Diabetes CSV Summary
- member_count: `2`
- headers_total: `18`
- rows_sampled_total: `1536`

## Tongue Dataset Summary
- image_total: `2750`
- split_counts: `{'test': 50, 'train': 2100, 'unknown': 600}`
- class_counts: `{'diabetes': 1375, 'nondiabetes': 1375}`

## Notebook Review
- included_in_bio_pipeline: `False`
- reason: `Notebook targets WHO life-expectancy regression and was excluded from HIV/Lupus/DM2 technical pack.`

JSON: `/home/fahbrain/projects/omnimind/reports_runtime/bio_external_dm2_lupus_wave_qdrant_materialization_20260218T182226Z.json`
