# Qdrant Astro Schema Audit (20260218T231041Z)

- total_collections: `162`
- astro_or_positional_collections: `5`

## Collections
- `sdss_structures_objectlevel_live_v2` count=`405000` sample_ra_dec_z=`50/50` sample_location=`50/50`
- `sdss_structures_objectlevel_live` count=`163152` sample_ra_dec_z=`50/50` sample_location=`50/50`
- `astro_desi_lya_objectlevel_live` count=`24724` sample_ra_dec_z=`50/50` sample_location=`50/50`
- `astro_desi_lya_sample_live` count=`22` sample_ra_dec_z=`0/22` sample_location=`0/22`
- `phys_accelerated_structure_horizon_thermo_live` count=`3` sample_ra_dec_z=`0/3` sample_location=`0/3`
