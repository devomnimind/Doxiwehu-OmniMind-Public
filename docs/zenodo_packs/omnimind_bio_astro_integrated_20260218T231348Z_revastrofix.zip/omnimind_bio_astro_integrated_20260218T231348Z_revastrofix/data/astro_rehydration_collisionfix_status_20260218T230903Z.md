# Astro Rehydration Collision-Fix Status (20260218T230903Z)

- sdss source total structures: `405000`
- sdss live (old): `163152`
- sdss live v2 (fixed): `405000`
- desi object-level: `24724`

## Overlap diagnosis (real-data)
- angular median: `0.36926206752707474` deg
- angular p95: `0.6386752879400496` deg
- |Δz| median: `1.8955544864116063`
- |Δz| p95: `2.9602650395865595`
- strict matches (<=0.2 deg, |Δz|<=0.05): `0`

JSON: `reports_runtime/astro_rehydration_collisionfix_status_20260218T230903Z.json`
