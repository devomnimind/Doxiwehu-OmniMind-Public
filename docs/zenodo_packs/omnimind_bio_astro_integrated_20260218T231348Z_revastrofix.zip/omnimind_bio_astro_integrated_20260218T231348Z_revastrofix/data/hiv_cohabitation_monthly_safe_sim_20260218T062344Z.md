# HIV Cohabitation Monthly Safe Simulation (20260218T062344Z)

- months: `6`
- runs_per_mode: `48`

## Comparative (cohabit - common)
- `isolated_A`: cohabitation=0.0612, host_preservation=0.0552, benign_preservation=0.1722, suppression=0.0000, host_loss_days=0.00, severe_loss_days=-30.58
- `isolated_B`: cohabitation=0.0606, host_preservation=0.0546, benign_preservation=0.1706, suppression=-0.0000, host_loss_days=0.00, severe_loss_days=-31.15
- `mixed_A_B`: cohabitation=0.0735, host_preservation=0.0896, benign_preservation=0.1721, suppression=-0.0000, host_loss_days=0.00, severe_loss_days=-3.69

## Intent
- Priorizar convivência com proteção: manter hospedeiro + conter carga viral + reduzir falso positivo em benignos.
- `cohabitation_index` mais alto é melhor.

JSON: `/home/fahbrain/projects/omnimind/reports_runtime/hiv_cohabitation_monthly_safe_sim_20260218T062344Z.json`
