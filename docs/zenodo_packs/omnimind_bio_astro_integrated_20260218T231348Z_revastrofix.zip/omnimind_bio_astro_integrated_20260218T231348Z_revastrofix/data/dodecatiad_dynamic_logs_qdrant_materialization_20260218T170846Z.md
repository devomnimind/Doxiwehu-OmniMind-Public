# Dodecatiad Dynamic Logs Materialization (20260218T170846Z)

- collection: `dodecatiad_metrics_dynamic_logs_live`
- input_jsonl: `/home/fahbrain/projects/omnimind/data/reports/maps/dodecatiad_metrics_timeseries.jsonl`
- points_upserted: `10536`
- vector_size: `13`

## Variance summary
- phi: std=`0.35499725231563717` min=`0.0` max=`2.3`
- sigma: std=`0.09624922239499277` min=`0.5` max=`1.0`
- epsilon: std=`0.07888638136190605` min=`0.49` max=`0.99`
- aleph: std=`0.12325070092797794` min=`0.0` max=`0.89`
- lambda_: std=`0.13400892987129093` min=`0.19` max=`0.97`
- axiom: std=`1.5292448387775632` min=`22.3` max=`100.0`

JSON: `reports_runtime/dodecatiad_dynamic_logs_qdrant_materialization_20260218T170846Z.json`
