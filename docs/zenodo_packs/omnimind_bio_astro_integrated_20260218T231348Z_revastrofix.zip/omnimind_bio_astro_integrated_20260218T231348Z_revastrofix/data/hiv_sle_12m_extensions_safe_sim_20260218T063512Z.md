# HIV+SLE 12M Safe Extensions (20260218T063512Z)

- months: `12`
- runs: `60`

## HIV Scenarios (cohabitation_score_m12)
- `latency_focus`: score=0.8843, host=0.9924, benign=0.8525, viral=0.3111, infl=0.2324
- `adp_enhanced`: score=0.9080, host=0.9934, benign=0.8750, viral=0.1751, infl=0.2326
- `pyroptosis_inhibited`: score=0.9066, host=0.9938, benign=0.8634, viral=0.2458, infl=0.1300
- `mixed_latency_adp`: score=0.9021, host=0.9929, benign=0.8662, viral=0.1996, infl=0.2330

## SLE Initial Prototype (M12)
- score=0.9273, host=0.9867, benign=0.9939, auto_bad=0.0093, treg=0.3668

JSON: `/home/fahbrain/projects/omnimind/reports_runtime/hiv_sle_12m_extensions_safe_sim_20260218T063512Z.json`
