# New ZIP Qdrant Materialization (20260218T204524Z)

- materialized_total: `13` / `13`
- vector_size: `13`

## Collections
- `bio_microbiome_ship_trend_glaucoma_live`: points_after=`80`, records={'file_meta': 1, 'table_row': 79}, table_rows=`79`
- `bio_colorectal_activity_bmi_live`: points_after=`4545`, records={'file_meta': 1, 'table_row': 4544}, table_rows=`4544`
- `bio_16s_gut_microbiome_meta_live`: points_after=`458`, records={'file_meta': 152, 'table_row': 306}, table_rows=`306`
- `phys_emergent_hydrodynamics_longrange_magnet_live`: points_after=`6752`, records={'file_meta_outer': 1, 'file_meta_nested': 3807, 'nested_table_row_sample': 2944}, table_rows=`2944`
- `phys_linf_330028100_live`: points_after=`1`, records={'file_meta': 1}, table_rows=`0`
- `bio_insectsound_18682538_live`: points_after=`2`, records={'file_meta': 2}, table_rows=`0`
- `cryo_lakeice_18682467_live`: points_after=`2`, records={'file_meta': 2}, table_rows=`0`
- `climate_nicam_highresmip_mcs_sa_live`: points_after=`10002`, records={'file_meta': 2, 'table_row': 10000}, table_rows=`10000`
- `phys_accelerated_structure_horizon_thermo_live`: points_after=`3`, records={'file_meta': 3}, table_rows=`0`
- `stats_uncertainty_weighted_param_fit_live`: points_after=`1`, records={'file_meta': 1}, table_rows=`0`
- `infra_scewero_deliverable_summer_live`: points_after=`12`, records={'file_meta': 12}, table_rows=`0`
- `bio_reproductive_obesity_microbiome_live`: points_after=`3`, records={'file_meta': 3}, table_rows=`0`
- `bio_mosites_microbiome_kenya_live`: points_after=`602`, records={'file_meta': 2, 'table_row': 600}, table_rows=`600`

## Linkage Reassessment
- gap_dm2_microbiome_wrapper: `EM_REVISAO_LOCAL`
- note: New real local microbiome collections ingested; dedicated DM2-gut validator must be rerun with these sources integrated.

JSON: `/home/fahbrain/projects/omnimind/reports_runtime/new_zip_qdrant_materialization_20260218T204524Z.json`
