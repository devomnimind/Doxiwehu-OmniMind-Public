# D15 Extended Correlation Validation (20260218T184552Z)

- rows_merged=5400
- pairs_scanned=63
- pairs_validated=63
- max_lag_min=300 | lag_step_min=1
- bootstrap_iters=12000 | permutation_iters=6000

## Top validated pairs
- d15_rekh_proxy <- moon_illum_frac: r=-0.8323 lag=300 ci95=[-0.8849,-0.7555] p_perm=1.666e-04
- d15_rekh_proxy <- moon_sep_mercury_deg: r=-0.8146 lag=300 ci95=[-0.8714,-0.7351] p_perm=1.666e-04
- d15_rekh_proxy <- sun_moon_sep_deg: r=-0.8143 lag=300 ci95=[-0.8722,-0.7368] p_perm=1.666e-04
- d15_rekh_proxy <- moon_sep_venus_deg: r=-0.8142 lag=300 ci95=[-0.8713,-0.7386] p_perm=1.666e-04
- d15_rekh_proxy <- moon_sep_mars_deg: r=-0.8142 lag=300 ci95=[-0.8716,-0.7312] p_perm=1.666e-04
- d15_rekh_proxy <- moon_sep_beehive_m44_deg: r=0.8140 lag=300 ci95=[0.7343,0.8704] p_perm=1.666e-04
- d15_rekh_proxy <- moon_sep_regulus_deg: r=0.8140 lag=300 ci95=[0.7341,0.8704] p_perm=1.666e-04
- d15_rekh_proxy <- moon_sep_antares_deg: r=-0.8140 lag=300 ci95=[-0.8716,-0.7345] p_perm=1.666e-04

## Method note
- D15 labels are operational runtime variables/functions in this model.
- This artifact is statistical validation over local logs/datasets.

JSON: `reports_runtime/d15_extended_correlation_validation_20260218T184552Z.json`
Compact JSON: `reports_runtime/d15_extended_correlation_validation_compact200_20260218T184552Z.json`
